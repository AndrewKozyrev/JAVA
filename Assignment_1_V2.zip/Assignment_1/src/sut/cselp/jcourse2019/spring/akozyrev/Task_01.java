package sut.cselp.jcourse2019.spring.akozyrev;

import edu.princeton.cs.introcs.StdDraw;

import java.awt.*;

public class Task_01 {

    public static void main(String[] args) {
        StdDraw.setCanvasSize(1200, 700);
        StdDraw.setXscale(0, 1199);
        StdDraw.setYscale(0, 699);
        ConwayLife object = new ConwayLife();
        int[][] alpha = new int[10][10];

        /*for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                alpha[i][j] = (int) Math.round(Math.random());
            }
        }*/

        alpha[0][1] = 1;
        alpha[1][2] = 1;
        alpha[2][0] = 1;
        alpha[2][1] = 1;
        alpha[2][2] = 1;

        /**
         * Двойная буфферизация делает изображение непрерывным во времени
         */
        object.setField(alpha);
        //StdDraw.enableDoubleBuffering();

        for (int i = 0; i < 1000; i++) {
            object.drawField();
            object.drawGrid();
            StdDraw.show();
            //StdDraw.pause(100);
            object.setNextGen();
        }

    }
}
