package sut.cselp.jcourse2019.spring.akozyrev;

import edu.princeton.cs.introcs.StdDraw;

public class Task_01 {

    public static void main(String[] args) {
        final int DIMENSION_1 = 700;
        final int DIMENSION_2 = 1200;

        StdDraw.setCanvasSize(1200, 700);
        StdDraw.setXscale(0, 1199);
        StdDraw.setYscale(0, 699);
        ConwayLife object1 = new ConwayLife(DIMENSION_1, DIMENSION_2);
        int[][] alpha = new int[DIMENSION_1][DIMENSION_2];

        for (int i = 0; i < DIMENSION_1; i++) {
            for (int j = 0; j < DIMENSION_2; j++) {
                alpha[i][j] = (int) Math.round(Math.random());
            }
        }


        {
            alpha[0][1] = 1;
            alpha[1][2] = 1;
            alpha[2][0] = 1;
            alpha[2][1] = 1;
            alpha[2][2] = 1;
//            alpha[0][DIMENSION_2 - 2] = 1;
//            alpha[1][DIMENSION_2 - 1] = 1;
//            alpha[2][DIMENSION_2 - 4] = 1;
//            alpha[2][DIMENSION_2 - 3] = 1;
//            alpha[2][DIMENSION_2 - 2] = 1;

            alpha[DIMENSION_1 - 2][DIMENSION_2 - 3] = 1;
            alpha[DIMENSION_1 - 1][DIMENSION_2 - 2] = 1;
            alpha[DIMENSION_1 - 3][DIMENSION_2 - 3] = 1;
            alpha[DIMENSION_1 - 3][DIMENSION_2 - 2] = 1;
            alpha[DIMENSION_1 - 3][DIMENSION_2 - 1] = 1;

//            alpha[DIMENSION_1 - 3][1] = 1;
//            alpha[DIMENSION_1 - 2][2] = 1;
//            alpha[DIMENSION_1 - 1][0] = 1;
//            alpha[DIMENSION_1 - 1][1] = 1;
//            alpha[DIMENSION_1 - 1][2] = 1;
        }

        StdDraw.enableDoubleBuffering();

        object1.setField(alpha);

        while (true) {
            object1.drawField();
            //object1.drawGrid();
            StdDraw.show();
            //StdDraw.pause(1);
            object1.setNextGen();
        }

    }
}
