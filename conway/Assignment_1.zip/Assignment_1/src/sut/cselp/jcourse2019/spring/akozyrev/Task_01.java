package sut.cselp.jcourse2019.spring.akozyrev;

import edu.princeton.cs.introcs.StdDraw;

import java.awt.*;

public class Task_01 {

    public static void main(String[] args) {
        StdDraw.setCanvasSize(1200, 700);
        StdDraw.setXscale(0, 1199);
        StdDraw.setYscale(0, 699);
        Conway_Life object = new Conway_Life();
        int[][] alpha = new int[10][10];

        /*for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                alpha[i][j] = (int) Math.round(Math.random());
            }
        }*/

        alpha[0][1] = 1;
        alpha[1][2] = 1;
        alpha[2][0] = 1;
        alpha[2][1] = 1;
        alpha[2][2] = 1;

        object.setField(alpha);
        StdDraw.enableDoubleBuffering();

        for (int i = 0; i < 28; i++) {
            object.drawField();
            StdDraw.setPenColor(Color.RED);
            StdDraw.square(235, 235, 135);
            StdDraw.line( 100, 130, 370, 130);
            StdDraw.line( 100, 160, 370, 160);
            StdDraw.line( 100, 190, 370, 190);
            StdDraw.line( 100, 220, 370, 220);
            StdDraw.line( 100, 250, 370, 250);
            StdDraw.line( 100, 280, 370, 280);
            StdDraw.line( 100, 310, 370, 310);
            StdDraw.line( 100, 340, 370, 340);

            StdDraw.line( 130, 100, 130, 370);
            StdDraw.line( 160, 100, 160, 370);
            StdDraw.line( 190, 100, 190, 370);
            StdDraw.line( 220, 100, 220, 370);
            StdDraw.line( 250, 100, 250, 370);
            StdDraw.line( 280, 100, 280, 370);
            StdDraw.line( 310, 100, 310, 370);
            StdDraw.line( 340, 100, 340, 370);
            StdDraw.show();
            StdDraw.pause(100);
            object.setNextGen();
        }

        System.out.println( object.countNeighbours(2, 9));

    }
}
