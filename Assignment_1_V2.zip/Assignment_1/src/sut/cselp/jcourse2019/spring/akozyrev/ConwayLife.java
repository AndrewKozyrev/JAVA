package sut.cselp.jcourse2019.spring.akozyrev;

import edu.princeton.cs.introcs.StdDraw;

import java.awt.*;
import java.util.Arrays;

public class ConwayLife {
    final int RowDim = 10;
    final int ColDim = 10;
    int[][] field = new int[RowDim][ColDim];

    public void setField(int[][] given) {
        this.field = given;
    }


    /**
     * Этот метод рисует текущее состояние поля, функции StdDraw:: DoubleBuffering позволяет сначала рисовать
     * изображение в буфер (скорее всего через какие-то быстрые регистры), а затем только выводит весь
     * рисунок на экран. В результате получается рисовать на порядки быстрее
     */
    public void drawField() {
        StdDraw.clear();
        StdDraw.setPenColor(Color.BLACK);
        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field[i].length; j++) {
                if (field[i][j] == 1) {
                    StdDraw.filledCircle(30 * i + 100, 30 * j + 100, 4);
                }
            }
        }
    }

    public void displayField() {
        System.out.println(Arrays.deepToString(this.field));
    }

    public void setNextGen() {

        int[][] NextField = new int[field.length][field[0].length];

        for (int i = 0; i < field.length; i++) {
            for (int j = 0; j < field[i].length; j++) {
                int neighbour = 0;
                neighbour = countNeighbours(i, j);

                switch (neighbour) {
                    case 0:
                        NextField[i][j] = 0;
                        break;

                    case 1:
                        NextField[i][j] = 0;
                        break;

                    case 2:
                        if (this.getCellStatus(i, j)) {
                            NextField[i][j] = 1;
                        } else {
                            NextField[i][j] = 0;
                        }
                        break;

                    case 3:
                        NextField[i][j] = 1;
                        break;

                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        NextField[i][j] = 0;
                        break;

                    default:
                        throw new RuntimeException("Impossible number of neighbours.");
                }
            }
        }
        for (int i = 0; i < field.length; i++) {
            System.arraycopy(NextField[i], 0, field[i], 0, field[i].length);
        }
    }

    public boolean getCellStatus(int row, int column) {
        if (this.field[row][column] == 1)
            return true;
        else
            return false;
    }

    public int countNeighbours(int row, int column) {
        int count = 0;
        int rowUp = row - 1;
        int rowDown = row + 1;
        int columnLeft = column - 1;
        int columnRight = column + 1;

        if (row == 0) {
            rowUp = field.length - 1;
        }
        if (row == field.length - 1) {
            rowDown = 0;
        }
        if (column == 0) {
            columnLeft = field[row].length - 1;
        }
        if (column == field[row].length - 1) {
            columnRight = 0;
        }

        count += field[rowUp][column];
        count += field[rowUp][columnLeft];
        count += field[rowUp][columnRight];
        count += field[row][columnLeft];
        count += field[row][columnRight];
        count += field[rowDown][columnLeft];
        count += field[rowDown][columnRight];
        count += field[rowDown][column];

        return count;
    }

    public void drawGrid() {
        for (int i = 1; i < field.length; i++) {
            StdDraw.setPenColor(Color.RED);
            StdDraw.square(100 + 30.0 * (field.length - 1) / 2, 100 + 30.0 * (field[i].length - 1) / 2, 135);
            //горизонтальные линии
            StdDraw.line(100, 100 + 30 * i, 100 + 30 * (field[i].length - 1), 100 + 30 * i);
            //верикальные линии
            StdDraw.line(100 + 30 * i, 100, 100 + 30 * i, 100 + 30 * (field.length - 1));
        }
    }
}
