public class Exercise_01 {

  public static void main(String[] args) {

    double variable1 = 4.5d;
    byte variable2 = Byte.MAX_VALUE;

    System.out.println(variable1);
    System.out.println(variable2);

  }
}
