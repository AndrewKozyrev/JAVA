package sut.cselp.jcourse2019.spring.akozyrev;

import edu.princeton.cs.introcs.StdDraw;

import java.awt.*;
import java.nio.Buffer;
import java.util.Arrays;

public class Conway_Life<field> {
    final int N = 10;
    int[][] field = new int[N][N];

    public void setField(int[][] given) {
        this.field = given;
    }

    public void drawField() {
        StdDraw.enableDoubleBuffering();
        StdDraw.clear();
        StdDraw.setPenColor(Color.BLACK);
        for (int i = 0; i < this.N; i++) {
            for (int j = 0; j < this.N; j++) {
                if (this.field[i][j] == 1) {
                    StdDraw.filledCircle(30 * i + 100, 30 * j + 100, 4);
                }
            }
        }
    }

    public void displayField() {
        System.out.println(Arrays.deepToString(this.field));
    }

    public void setNextGen() {

        int[][] BufferField = new int[2][this.N];

        for (int i = 0, buff = 0; i < this.N; i++, buff++) {
            for (int j = 0; j < this.N; j++) {
                int neighbour = 0;
                neighbour = countNeighbours(i, j);

                switch (neighbour) {
                    case 0:
                        BufferField[buff][j] = 0;
                        break;

                    case 1:
                        BufferField[buff][j] = 0;
                        break;

                    case 2:
                        if (this.getCellStatus(i, j)) {
                            BufferField[buff][j] = 1;
                        } else {
                            BufferField[buff][j] = 0;
                        }
                        break;

                    case 3:
                        BufferField[buff][j] = 1;
                        break;

                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                        BufferField[buff][j] = 0;
                        break;

                    default:
                        throw new RuntimeException("Impossible number of neighbours.");
                }
            }

            if ((i == (this.N - 1)) && (buff == 1)) {
                System.arraycopy(BufferField[0], 0, this.field[i - 1], 0, this.N);
                System.arraycopy(BufferField[1], 0, this.field[i], 0, this.N);
            } else if ((i == (N - 1)) && (buff == 0)) {
                System.arraycopy(BufferField[0], 0, this.field[i], 0, this.N);
                System.arraycopy(BufferField[1], 0, this.field[i - 1], 0, this.N);
            } else if ((buff == 0) && (i != 0)) {
                System.arraycopy(BufferField[1], 0, this.field[i - 1], 0, this.N);
            } else if (buff == 1) {
                System.arraycopy(BufferField[0], 0, this.field[i - 1], 0, this.N);
                buff = -1;
            }
        }
    }

    public boolean getCellStatus(int row, int column) {
        if (this.field[row][column] == 1)
            return true;
        else
            return false;
    }

    public int countNeighbours(int row, int column) {
        int count = 0;
        int rowUp = row - 1;
        int rowDown = row + 1;
        int columnLeft = column - 1;
        int columnRight = column + 1;

        if (row == 0) {
            rowUp = this.N - 1;
        }
        if (row == this.N - 1) {
            rowDown = 0;
        }
        if (column == 0) {
            columnLeft = this.N - 1;
        }
        if (column == this.N - 1) {
            columnRight = 0;
        }

        if (this.field[rowUp][column] == 1) {
            count++;
        }
        if (this.field[rowUp][columnLeft] == 1) {
            count++;
        }
        if (this.field[rowUp][columnRight] == 1) {
            count++;
        }
        if (this.field[row][columnLeft] == 1) {
            count++;
        }
        if (this.field[row][columnRight] == 1) {
            count++;
        }
        if (this.field[rowDown][columnLeft] == 1) {
            count++;
        }
        if (this.field[rowDown][columnRight] == 1) {
            count++;
        }
        if (this.field[rowDown][column] == 1) {
            count++;
        }

        return count;
    }
}
